sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("ns.winning_product_uploads.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
